# Code of Conduct
I’m committed to a respectful, inclusive community. Be kind, credit sources, and keep feedback constructive. Reports: open an issue or email me.
