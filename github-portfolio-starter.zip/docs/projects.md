---
title: "Projects"
layout: default
---

# Projects

- [CubeSat Solar Panel Release Mechanism](../projects/cubesat-release-mechanism.md)
- [TVC Mini-Rocket (Arduino + IMU6050)](../projects/tvc-mini-rocket.md)
- [CFD: Nozzle Side-Force via Deflected Surfaces](../projects/cfd-nozzle-sideforce.md)
