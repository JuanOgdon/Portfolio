# Contributing
- File a descriptive issue first.
- Keep PRs focused and small.
- Include a short demo (gif/screenshot) when relevant.
